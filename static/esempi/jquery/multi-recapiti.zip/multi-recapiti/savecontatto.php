<?php
if($_POST['recapiti']){
  $array_recapiti = $_POST['recapiti'];
  foreach ($array_recapiti as $recapito) {
    if (strlen($recapito)>0) {
      //operazioni sul singolo recapito
      echo $recapito."<br />";
    }
  }
}
?>