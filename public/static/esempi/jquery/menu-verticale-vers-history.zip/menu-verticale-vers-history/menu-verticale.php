<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>Menu verticale jQuery con effetto fisarmonica | MaiNick Web</title> 
 
<link rel="stylesheet" type="text/css" href="demo.css" /> 
 
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script> 
<script type="text/javascript" src="jquery.easing.1.3.js"></script> 
 
<script type="text/javascript" src="script.js"></script> 
 
</head> 
 
<body> 
 
<div id="main"> 
 
  <h1>Menu verticale jQuery &amp; CSS</h1> 

  <h2>Vedi il <a href="http://www.mainickweb.com/menu-verticale-jquery-con-effetto-fisarmonica/">tutoriale originale &raquo;</a></h2> 
 
  <?php $array_label_menu = array('jquery' => '', 'php' => '', 'css' => '', 'firefox' => '') ?>
  <?php $submenu_open = (isset($_GET['menu']) && $_GET['menu']!='') ? $_GET['menu'] : 'php'; ?>
  <?php $array_label_menu[$submenu_open] = 'sub-menu-open'; ?>
  <ul class="container"> 
      <li class="menu"> 
      
          <ul> 
		    <li class="title"><a href="http://www.mainickweb.com/category/jquery/?menu=jquery">Categoria jQuery</a><img src="bullet_arrow_down.png" /></li> 
 
            <li class="sub-menu <?php echo $array_label_menu['jquery'] ?>"> 
                <ul> 
                    <li><a href="http://www.mainickweb.com/creare-un-menu-a-lista-in-ordine-alfabetico-con-jquery/?menu=jquery">Articolo 1</a></li> 
                    <li><a href="http://www.mainickweb.com/ricerca-in-modo-interattiva-con-jquery/?menu=jquery">Articolo 2</a></li>
                    <li><a href="http://www.mainickweb.com/colonne-adattabili-a-layout-liquido-con-css-e-jquery/?menu=jquery">Articolo 3</a></li>
                    <li><a href="http://www.mainickweb.com/sfondo-a-tutto-schermo-con-jquery/?menu=jquery">Articolo 4</a></li> 
                </ul> 
			</li> 
 
          </ul> 
          
      </li> 
      
      <li class="menu"> 
      
          <ul> 
		    <li class="title"><a href="http://www.mainickweb.com/category/php/?menu=php">Categoria PHP</a><img src="bullet_arrow_down.png" /></li>
 
            <li class="sub-menu <?php echo $array_label_menu['php'] ?>"> 
                <ul>
                    <li><a href="http://www.mainickweb.com/utilizzare-piu-istruzioni-sql-prepare-con-php-mysqli/?menu=php">Articolo 1</a></li> 
                    <li><a href="http://www.mainickweb.com/conversioni-tra-tipi-di-dati/?menu=php">Articolo 2</a></li> 
					<li><a href="http://www.mainickweb.com/debug-primitivo-di-applicazioni-php/?menu=php">Articolo 3</a></li> 
					<li><a href="http://www.mainickweb.com/notazione-heredoc-sistema-per-specificare-stringhe-in-php/?menu=php">Articolo 4</a></li> 
                </ul> 
			</li> 
 
          </ul> 
          
      </li> 
 
      
      <li class="menu"> 
      
          <ul> 
		    <li class="title"><a href="http://www.mainickweb.com/category/css/?menu=css">Categoria CSS</a><img src="bullet_arrow_down.png" /></li> 
 
            <li class="sub-menu <?php echo $array_label_menu['css'] ?>"> 
                <ul> 
                    <li><a href="http://www.mainickweb.com/creare-una-lista-a-due-colonne-fissa-liquida/?menu=css">Articolo 1</a></li> 
                    <li><a href="http://www.mainickweb.com/come-ottenere-sempre-la-compatibilit-cross-browser/?menu=css">Articolo 2</a></li> 
					<li><a href="http://www.mainickweb.com/visualizzare-propri-font-nelle-pagine-web/?menu=css">Articolo 3</a></li> 
					<li><a href="http://www.mainickweb.com/hack-css-per-firefox-opera-safari-e-internet-explorer/?menu=css">Articolo 4</a></li>
                </ul> 
			</li> 
 
          </ul> 
          
      </li> 
 
    
      <li class="menu"> 
      
          <ul> 
	
			<li class="title"><a href="http://www.mainickweb.com/category/firefox/?menu=firefox">Categoria Firefox</a><img src="bullet_arrow_down.png" /></li>
			
			<li class="sub-menu <?php echo $array_label_menu['firefox'] ?>">
				<ul>
			    	<li><a href="http://www.mainickweb.com/hack-css-per-firefox-opera-safari-e-internet-explorer/?menu=firefox">Articolo 1</a></li>
			        <li><a href="http://www.mainickweb.com/firefox-3-le-caratteristiche/?menu=firefox">Articolo 2</a></li>
			    </ul>
			</li>
 
          </ul> 
          
      </li> 
  </ul> 
 
<div class="clear"></div> 
 
</div>

</body> 
</html>